(function () {
  angular.module('ita-app',
    ['ui.router']
  )
})();