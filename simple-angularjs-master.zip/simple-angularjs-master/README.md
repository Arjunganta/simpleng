# Simple AngularJS Project

## Description
The most pure angularjs v1.6 project


## Usage

### Dependencies Installation

```bash
npm install
```

### Run & Check in your browser

Run command

```bash
npm run start
```


And see your browser

[http://127.0.0.1:3000](http://127.0.0.1:3000)

Then you will see the most regular angular.js hello world way in directly define in html file.